
import NavBar from './Components/NavBar';

function App() {
  
  return (
    <div className="App">
      <header className="App-header">
        
        <NavBar />
       
   
      </header>
    </div>
  );
}

export default App;
